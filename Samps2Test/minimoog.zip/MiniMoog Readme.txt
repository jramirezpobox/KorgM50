OASYS MiniMoog Bass

8 Samples total

These are the mappings, no tuning is needed, what I did was simply use patch
number "A-86" Stein Bass, and substituted the multisamples.



1 = C4 to F#4
2 = G4 to B4
3 = C5 to F#5
4 = G5 to B5
5 = C6 to F#6
6 = G6 to B6
7 = C7 to F#7
8 = G7 to C8